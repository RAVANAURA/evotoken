 function sendBatteryPercentage(percentage) {
            let xhttp = new XMLHttpRequest();
            xhttp.open('POST', 'check.php', true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('batteryPercentage=' + percentage);
        }

        // Function to periodically check the battery status and send it to the backend
        function checkBatteryStatus() {
            if (navigator.getBattery) {
                navigator.getBattery().then(function(battery) {
                    let batteryPercentage = battery.level * 100;
                    sendBatteryPercentage(batteryPercentage);
                });
            }
        }

        // Call the checkBatteryStatus function every 10 seconds (adjust as needed)
        setInterval(checkBatteryStatus, 10000); // 10000 milliseconds = 10 seconds
